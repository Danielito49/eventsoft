from django.http import HttpResponse


from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.views.decorators.http import require_http_methods
from django.utils import timezone
from django.db.models import Prefetch, Q
from django.core.files.base import ContentFile
from django.core.mail import EmailMessage
from django.template.loader import render_to_string

from io import BytesIO

from app_participantes.models import Participante, ParticipanteEvento
from app_areas.models import Area, Categoria
from app_asistentes.models import Asistente, AsistenteEvento
from app_evaluadores.models import Evaluador, EvaluadorEvento
from .models import Evento, EventoCategoria
from app_usuarios.models import Usuario, Rol, RolUsuario
from .models import InscripcionPendiente

import random
import string
import qrcode
import uuid


def generar_clave():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=10))

def ver_eventos(request):
    area = request.GET.get('area')
    categoria = request.GET.get('categoria')
    ciudad = request.GET.get('ciudad')
    fecha = request.GET.get('fecha')
    nombre = request.GET.get('nombre')
    eventos = Evento.objects.filter(eve_estado__in=['Aprobado', 'Inscripciones Cerradas'])
    if ciudad:
        eventos = eventos.filter(eve_ciudad__icontains=ciudad)
    if fecha:
        eventos = eventos.filter(eve_fecha_inicio__lte=fecha, eve_fecha_fin__gte=fecha)
    if nombre:
        eventos = eventos.filter(eve_nombre__icontains=nombre)
    if categoria:
        eventos = eventos.filter(eventocategoria__categoria__cat_codigo=categoria)
    if area:
        eventos = eventos.filter(eventocategoria__categoria__cat_area_fk__are_codigo=area)
    areas = Area.objects.all()
    categorias = Categoria.objects.filter(cat_area_fk__are_codigo=area) if area else Categoria.objects.all()
    context = {
        'eventos': eventos.distinct(),
        'areas': areas,
        'categorias': categorias,
    }
    return render(request, 'eventos.html', context)


def detalle_evento(request, eve_id):
    evento = get_object_or_404(Evento.objects.select_related('eve_administrador_fk'), pk=eve_id)
    categorias = EventoCategoria.objects.select_related('categoria__cat_area_fk').filter(evento=evento)
    return render(request, 'detalle_evento.html', {
        'evento': evento,
        'categorias': categorias,
    })


@require_http_methods(["GET", "POST"])
def inscripcion_asistente(request, eve_id):
    evento = get_object_or_404(Evento, pk=eve_id)
    if request.method == 'GET':
        return render(request, "inscribirse_asistente.html", {'evento': evento})
    documento = request.POST.get('asi_id')
    nombres = request.POST.get('asi_nombres')
    apellidos = request.POST.get('asi_apellidos')
    correo = request.POST.get('asi_correo')
    telefono = request.POST.get('asi_telefono')
    soporte = request.FILES.get('soporte_pago')
    if evento.eve_capacidad <= 0:
        messages.error(request, "Este evento ya no tiene cupos disponibles.")
        return redirect('ver_eventos')
    usuario = Usuario.objects.filter(Q(email=correo) | Q(documento=documento)).first()
    if usuario:
        datos_iguales = (
            usuario.documento == documento and
            usuario.first_name.strip().lower() == nombres.strip().lower() and
            usuario.last_name.strip().lower() == apellidos.strip().lower() and
            usuario.email.strip().lower() == correo.strip().lower() and
            (usuario.telefono or "").strip() == (telefono or "").strip()
        )
        if not datos_iguales:
            messages.error(request, "La información proporcionada no coincide con registros anteriores.")
            return redirect('inscripcion_asistente', eve_id=eve_id)
        if AsistenteEvento.objects.filter(asistente__usuario=usuario, evento=evento).exists():
            messages.warning(request, "Ya estás inscrito en este evento como asistente.")
            return redirect('ver_eventos')
    # Si pasa la validación, crear InscripcionPendiente y enviar correo
    
    pendiente = InscripcionPendiente.objects.create(
        rol='asistente',
        nombres=nombres,
        apellidos=apellidos,
        correo=correo,
        telefono=telefono,
        documento=documento,
        evento_id=evento.eve_id,
        archivo=soporte if soporte else None,
        datos_extra={}
    )
    # Enviar correo de confirmación
    
    confirm_url = request.build_absolute_uri(f"/evento/confirmar-inscripcion/{pendiente.token}/")
    cuerpo_html = render_to_string('plantilla_email.html', {
        'asunto': 'Confirmar inscripción como asistente',
        'mensaje': f"Hola {nombres},<br>Has solicitado inscribirte como asistente en el evento '{evento.eve_nombre}'.<br>Por favor confirma tu inscripción haciendo clic en el siguiente enlace:<br><a href='{confirm_url}'>Confirmar inscripción</a>"
    })
    email = EmailMessage(
        subject='Confirmar inscripción como asistente',
        body=cuerpo_html,
        to=[correo],
    )
    email.content_subtype = 'html'
    if soporte:
        email.attach(soporte.name, soporte.read(), soporte.content_type)
    email.send()
    return render(request, "confirmacion_asistente.html", {
        "nombre": nombres,
        "correo_enviado": True
    })

    
def inscribirse_participante(request, eve_id):
    evento = Evento.objects.prefetch_related(
        Prefetch('eventocategoria_set', queryset=EventoCategoria.objects.select_related('categoria'))
    ).filter(eve_id=eve_id).first()  
    if not evento:
        messages.error(request, "Evento no encontrado")
        return redirect('ver_eventos')
    if request.method == "POST":
        documento = request.POST.get('par_id')
        nombres = request.POST.get('par_nombres')
        apellidos = request.POST.get('par_apellidos')
        correo = request.POST.get('par_correo')
        telefono = request.POST.get('par_telefono')
        archivo = request.FILES.get('documentos')
        if not (documento and nombres and apellidos and correo):
            messages.error(request, "Por favor completa todos los campos obligatorios.")
            return redirect('inscripcion_participante', eve_id=eve_id)
        # Validación de datos como antes
        usuario = Usuario.objects.filter(Q(email=correo) | Q(documento=documento)).first()
        if usuario:
            datos_iguales = (
                usuario.documento == documento and
                usuario.first_name.strip().lower() == nombres.strip().lower() and
                usuario.last_name.strip().lower() == apellidos.strip().lower() and
                usuario.email.strip().lower() == correo.strip().lower() and
                (usuario.telefono or "").strip() == (telefono or "").strip()
            )
            if not datos_iguales:
                messages.error(request, "La información proporcionada no coincide con registros anteriores.")
                return redirect('inscripcion_participante', eve_id=eve_id)
            # Ya puede tener más de un rol, solo validamos consistencia
            if ParticipanteEvento.objects.filter(participante__usuario=usuario, evento=evento).exists():
                messages.warning(request, "Ya estás inscrito en este evento como participante.")
                return redirect('ver_eventos')
        # Si pasa la validación, crear InscripcionPendiente y enviar correo
        
        
        pendiente = InscripcionPendiente.objects.create(
            rol='participante',
            nombres=nombres,
            apellidos=apellidos,
            correo=correo,
            telefono=telefono,
            documento=documento,
            evento_id=evento.eve_id,
            archivo=archivo if archivo else None,
            datos_extra={}
        )
        # Enviar correo de confirmación
       
        confirm_url = request.build_absolute_uri(f"/evento/confirmar-inscripcion/{pendiente.token}/")
        cuerpo_html = render_to_string('plantilla_email.html', {
            'asunto': 'Confirmar inscripción como participante',
            'mensaje': f"Hola {nombres},<br>Has solicitado inscribirte como participante en el evento '{evento.eve_nombre}'.<br>Por favor confirma tu inscripción haciendo clic en el siguiente enlace:<br><a href='{confirm_url}'>Confirmar inscripción</a>"
        })
        email = EmailMessage(
            subject='Confirmar inscripción como participante',
            body=cuerpo_html,
            to=[correo],
        )
        email.content_subtype = 'html'
        if archivo:
            email.attach(archivo.name, archivo.read(), archivo.content_type)
        email.send()
        return render(request, "confirmacion_participante.html", {
            "nombre": nombres,
            "correo_enviado": True
        })
    return render(request, 'inscribirse_participante.html', {'evento': evento})



def inscribirse_evaluador(request, eve_id):
    evento = Evento.objects.prefetch_related(
        Prefetch('eventocategoria_set', queryset=EventoCategoria.objects.select_related('categoria'))
    ).filter(eve_id=eve_id).first()
    if not evento:
        messages.error(request, "Evento no encontrado")
        return redirect('ver_eventos')
    if request.method == "POST":
        documento = request.POST.get('eva_id')
        nombres = request.POST.get('eva_nombres')
        apellidos = request.POST.get('eva_apellidos')
        correo = request.POST.get('eva_correo')
        telefono = request.POST.get('eva_telefono')
        archivo = request.FILES.get('documentacion')
        if not (documento and nombres and apellidos and correo):
            messages.error(request, "Por favor completa todos los campos obligatorios.")
            return redirect('inscripcion_evaluador', eve_id=eve_id)
        usuario = Usuario.objects.filter(Q(documento=documento) | Q(email=correo)).first()
        if usuario:
            datos_iguales = (
                usuario.documento == documento and
                usuario.first_name.strip().lower() == nombres.strip().lower() and
                usuario.last_name.strip().lower() == apellidos.strip().lower() and
                usuario.email.strip().lower() == correo.strip().lower() and
                (usuario.telefono or "").strip() == (telefono or "").strip()
            )
            if not datos_iguales:
                messages.error(request, "La información proporcionada no coincide con registros anteriores.")
                return redirect('inscripcion_evaluador', eve_id=eve_id)
            if EvaluadorEvento.objects.filter(evaluador=usuario, evento=evento).exists():
                messages.warning(request, "Ya estás inscrito en este evento como evaluador.")
                return redirect('ver_eventos')
        # Si pasa la validación, crear InscripcionPendiente y enviar correo
        
        pendiente = InscripcionPendiente.objects.create(
            rol='evaluador',
            nombres=nombres,
            apellidos=apellidos,
            correo=correo,
            telefono=telefono,
            documento=documento,
            evento_id=evento.eve_id,
            archivo=archivo if archivo else None,
            datos_extra={}
        )
        # Enviar correo de confirmación
        confirm_url = request.build_absolute_uri(f"/evento/confirmar-inscripcion/{pendiente.token}/")
        cuerpo_html = render_to_string('plantilla_email.html', {
            'asunto': 'Confirmar inscripción como evaluador',
            'mensaje': f"Hola {nombres},<br>Has solicitado inscribirte como evaluador en el evento '{evento.eve_nombre}'.<br>Por favor confirma tu inscripción haciendo clic en el siguiente enlace:<br><a href='{confirm_url}'>Confirmar inscripción</a>"
        })
        email = EmailMessage(
            subject='Confirmar inscripción como evaluador',
            body=cuerpo_html,
            to=[correo],
        )
        email.content_subtype = 'html'
        if archivo:
            email.attach(archivo.name, archivo.read(), archivo.content_type)
        email.send()
        return render(request, "confirmacion_evaluador.html", {
            "nombre": nombres,
            "correo_enviado": True
        })
    return render(request, 'inscribirse_evaluador.html', {'evento': evento})

def confirmar_inscripcion(request, token):
    pendiente = InscripcionPendiente.objects.filter(token=token).first()
    if not pendiente:
        return render(request, "confirmacion_inscripcion.html", {"error": "El enlace de confirmación no es válido o ya fue usado."})

    # Buscar o crear usuario
    clave_generada = generar_clave()
    usuario, creado = Usuario.objects.get_or_create(
        email=pendiente.correo,
        defaults={
            "username": pendiente.correo.split('@')[0],
            "telefono": pendiente.telefono,
            "documento": pendiente.documento,
            "first_name": pendiente.nombres,
            "last_name": pendiente.apellidos,
            "password": clave_generada
        }
    )
    # Asignar rol si no lo tiene
    rol_obj = Rol.objects.filter(nombre__iexact=pendiente.rol).first()
    if rol_obj and not RolUsuario.objects.filter(usuario=usuario, rol=rol_obj).exists():
        RolUsuario.objects.create(usuario=usuario, rol=rol_obj)

    evento = Evento.objects.filter(eve_id=pendiente.evento_id).first()
    mensaje = ""
    # Enviar clave por correo
    cuerpo_html = render_to_string('plantilla_email.html', {
        'asunto': 'Clave de acceso a Eventsoft',
        'mensaje': f"Hola {pendiente.nombres},<br>Tu inscripción ha sido confirmada.<br>Tu clave de acceso es: <b>{clave_generada}</b><br>Guárdala para ingresar al sistema."
    })
    email = EmailMessage(
        subject='Clave de acceso a Eventsoft',
        body=cuerpo_html,
        to=[pendiente.correo],
    )
    email.content_subtype = 'html'
    email.send()

    if pendiente.rol == 'participante':
        participante, _ = Participante.objects.get_or_create(usuario=usuario)
        ParticipanteEvento.objects.create(
            participante=participante,
            evento=evento,
            par_eve_fecha_hora=timezone.now(),
            par_eve_documentos=pendiente.archivo,
            par_eve_estado='Pendiente',
            par_eve_clave=clave_generada
        )
        mensaje = f"¡Inscripción confirmada como participante en el evento '{evento.eve_nombre}'!"
    elif pendiente.rol == 'asistente':
        asistente, _ = Asistente.objects.get_or_create(usuario=usuario)
        estado = 'Aprobado' if evento.eve_tienecosto == 'NO' else 'Pendiente'
        # Generar QR si es aprobado
        qr_img = None
        if estado == 'Aprobado':
            qr = qrcode.make(f"Asistente:{usuario.documento}|Evento:{evento.eve_id}")
            buffer = BytesIO()
            qr.save(buffer, format="PNG")
            qr_img = ContentFile(buffer.getvalue(), name=f"qr_{usuario.documento}_{evento.eve_id}.png")
        AsistenteEvento.objects.create(
            asistente=asistente,
            evento=evento,
            asi_eve_fecha_hora=timezone.now(),
            asi_eve_estado=estado,
            asi_eve_clave=clave_generada,
            asi_eve_soporte=pendiente.archivo,
            asi_eve_qr=qr_img if qr_img else None
        )
        mensaje = f"¡Inscripción confirmada como asistente en el evento '{evento.eve_nombre}'!"
    elif pendiente.rol == 'evaluador':
        evaluador, _ = Evaluador.objects.get_or_create(usuario=usuario)
        EvaluadorEvento.objects.create(
            evaluador=usuario,
            evento=evento,
            eva_eve_estado='Pendiente',
            eva_eve_clave=clave_generada,
            eva_eve_fecha_hora=timezone.now(),
            eva_eve_documentos=pendiente.archivo
        )
        mensaje = f"¡Inscripción confirmada como evaluador en el evento '{evento.eve_nombre}'!"
    else:
        mensaje = "Rol no reconocido."

    pendiente.delete()
    return render(request, "confirmacion_inscripcion.html", {"mensaje": mensaje})