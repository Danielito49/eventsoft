import uuid
from django.utils import timezone


from django.db import models
from app_administradores.models import AdministradorEvento
from app_areas.models import Categoria

class Evento(models.Model):
    eve_id = models.AutoField(primary_key=True)
    eve_nombre = models.CharField(max_length=100)
    eve_descripcion = models.CharField(max_length=400)
    eve_ciudad = models.CharField(max_length=45)
    eve_lugar = models.CharField(max_length=45)
    eve_fecha_inicio = models.DateField()
    eve_fecha_fin = models.DateField()
    eve_estado = models.CharField(max_length=45)
    eve_imagen = models.ImageField(upload_to='eventos/imagenes/', null=True, blank=True)
    eve_capacidad = models.IntegerField()
    eve_tienecosto = models.CharField(max_length=2)
    eve_administrador_fk = models.ForeignKey(AdministradorEvento, on_delete=models.CASCADE, related_name='eventos')
    eve_programacion = models.FileField(upload_to='eventos/programaciones/', null=True, blank=True)
    eve_memorias = models.FileField(upload_to='eventos/memorias/', null=True, blank=True)

class EventoCategoria(models.Model):
    evento = models.ForeignKey(Evento, on_delete=models.CASCADE)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)

    class Meta:
        unique_together = (('evento', 'categoria'),)

class InscripcionPendiente(models.Model):
    ROLES = (
        ('participante', 'Participante'),
        ('asistente', 'Asistente'),
        ('evaluador', 'Evaluador'),
    )
    token = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    rol = models.CharField(max_length=20, choices=ROLES)
    nombres = models.CharField(max_length=100)
    apellidos = models.CharField(max_length=100)
    correo = models.EmailField()
    telefono = models.CharField(max_length=20, blank=True, null=True)
    documento = models.CharField(max_length=20)
    evento_id = models.IntegerField()
    fecha_creacion = models.DateTimeField(default=timezone.now)
    archivo = models.FileField(upload_to='inscripciones_pendientes/', blank=True, null=True)
    datos_extra = models.JSONField(blank=True, null=True)

    def __str__(self):
        return f"{self.rol} - {self.correo} - {self.evento_id}"