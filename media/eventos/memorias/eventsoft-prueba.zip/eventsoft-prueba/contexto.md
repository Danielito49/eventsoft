# 🧠 Contexto del Backend Django - Sistema de Eventos

Este documento contiene el modelo de datos completo del sistema, distribuido por apps, incluyendo clases, relaciones, llaves foráneas, y la configuración del panel de administración en Django.

---

## 📦 App: `areas/models.py`

```python
from django.db import models

class Area(models.Model):
    are_codigo = models.AutoField(primary_key=True)
    are_nombre = models.CharField(max_length=45)
    are_descripcion = models.CharField(max_length=400)

class Categoria(models.Model):
    cat_codigo = models.AutoField(primary_key=True)
    cat_nombre = models.CharField(max_length=45)
    cat_descripcion = models.CharField(max_length=400)
    cat_area_fk = models.ForeignKey(Area, on_delete=models.CASCADE, related_name='categorias')


📦 App: administradores/models.py

from django.db import models
from app_usuarios.models import Usuario

class AdministradorEvento(models.Model):
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE, null=True, blank=True, related_name='administrador')

    def __str__(self):
        return f"{self.usuario.username}"

📦 App: eventos/models.py

from django.db import models
from administradores.models import AdministradorEvento
from areas.models import Categoria

class Evento(models.Model):
    eve_id = models.AutoField(primary_key=True)
    eve_nombre = models.CharField(max_length=100)
    eve_descripcion = models.CharField(max_length=400)
    eve_ciudad = models.CharField(max_length=45)
    eve_lugar = models.CharField(max_length=45)
    eve_fecha_inicio = models.DateField()
    eve_fecha_fin = models.DateField()
    eve_estado = models.CharField(max_length=45)
    eve_imagen = models.ImageField(upload_to='eventos/imagenes/', null=True, blank=True)
    eve_capacidad = models.IntegerField()
    eve_tienecosto = models.CharField(max_length=2)
    eve_administrador_fk = models.ForeignKey(AdministradorEvento, on_delete=models.CASCADE, related_name='eventos')
    eve_programacion = models.FileField(upload_to='eventos/programaciones/', null=True, blank=True)
    eve_memorias = models.FileField(upload_to='eventos/memorias/', null=True, blank=True)

class EventoCategoria(models.Model):
    evento = models.ForeignKey(Evento, on_delete=models.CASCADE)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)

    class Meta:
        unique_together = (('evento', 'categoria'),)

📦 App: asistentes/models.py

from django.db import models
from app_eventos.models import Evento
from app_usuarios.models import Usuario

class Asistente(models.Model):
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE, related_name='asistente')

    def __str__(self):
        return f"{self.usuario.username}"

class AsistenteEvento(models.Model):
    asistente = models.ForeignKey(Asistente, on_delete=models.CASCADE)
    evento = models.ForeignKey(Evento, on_delete=models.CASCADE)
    asi_eve_fecha_hora = models.DateTimeField()
    asi_eve_estado = models.CharField(max_length=45)
    asi_eve_soporte = models.FileField(upload_to='asistentes/soportes/', null=True, blank=True)
    asi_eve_qr = models.ImageField(upload_to='asistentes/qr/', null=True, blank=True)
    asi_eve_clave = models.CharField(max_length=45)

    class Meta:
        unique_together = (('asistente', 'evento'),)


📦 App: participantes/models.py

from django.db import models
from app_eventos.models import Evento
from app_usuarios.models import Usuario

class Participante(models.Model):
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE, related_name='participante')

    def __str__(self):
        return f"{self.usuario.username}"

class ParticipanteEvento(models.Model):
    participante = models.ForeignKey(Participante, on_delete=models.CASCADE)
    evento = models.ForeignKey(Evento, on_delete=models.CASCADE)
    par_eve_fecha_hora = models.DateTimeField()
    par_eve_documentos = models.FileField(upload_to='participantes/documentos/', null=True, blank=True)
    par_eve_estado = models.CharField(max_length=45)
    par_eve_qr = models.ImageField(upload_to='participantes/qr/', null=True, blank=True)
    par_eve_clave = models.CharField(max_length=45)
    par_eve_valor = models.IntegerField(null=True, blank=True)

    class Meta:
        unique_together = (('participante', 'evento'),)


📦 App: evaluadores/models.py

from django.db import models
from app_eventos.models import Evento
from app_participantes.models import Participante
from app_usuarios.models import Usuario

class Evaluador(models.Model):
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE, related_name='evaluador')

    def __str__(self):
        return f"{self.usuario.username}"

class EvaluadorEvento(models.Model):
    evaluador = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    evento = models.ForeignKey(Evento, on_delete=models.CASCADE)
    eva_eve_documentos = models.FileField(upload_to='evaluadores/documentos/', null=True, blank=True)
    eva_eve_fecha_hora = models.DateTimeField()
    eva_eve_estado = models.CharField(max_length=45)
    eva_eve_qr = models.ImageField(upload_to='evaluadores/qr/', null=True, blank=True)
    eva_eve_clave = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        unique_together = (('evaluador', 'evento'),)

    def __str__(self):
        return f"{self.evaluador.get_full_name()} - {self.evento.eve_nombre}"

class Criterio(models.Model):
    cri_id = models.AutoField(primary_key=True)
    cri_descripcion = models.CharField(max_length=100)
    cri_peso = models.FloatField()
    cri_evento_fk = models.ForeignKey(Evento, on_delete=models.CASCADE, related_name='criterios')

class Calificacion(models.Model):
    evaluador = models.ForeignKey(Evaluador, on_delete=models.CASCADE)
    criterio = models.ForeignKey(Criterio, on_delete=models.CASCADE)
    participante = models.ForeignKey(Participante, on_delete=models.CASCADE)
    cal_valor = models.IntegerField()
    cal_observacion = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        unique_together = (('evaluador', 'criterio', 'participante'),)


📦 App: usuarios/models.py

from django.contrib.auth.models import AbstractUser
from django.db import models

class Usuario(AbstractUser):
    email = models.EmailField(unique=True)
    telefono = models.CharField(max_length=20, null=True, blank=True)
    documento = models.CharField(max_length=20)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    def __str__(self):
        return f"{self.username}"

class Rol(models.Model):
    nombre = models.CharField(max_length=30, unique=True)
    descripcion = models.TextField(blank=True)

    def __str__(self):
        return self.nombre

class RolUsuario(models.Model):
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='roles')
    rol = models.ForeignKey(Rol, on_delete=models.CASCADE)

    class Meta:
        unique_together = (('usuario', 'rol'),)

    def __str__(self):
        return f"{self.usuario.username} - {self.rol.nombre}"


⚙️ Configuración del Admin (usuarios/admin.py)

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Usuario, Rol, RolUsuario

class RolUsuarioInline(admin.TabularInline):
    model = RolUsuario
    extra = 1

class UsuarioAdmin(UserAdmin):
    list_display = ('username', 'email', 'documento', 'telefono', 'is_staff', 'is_active')
    list_filter = ('is_staff', 'is_active', 'is_superuser')
    search_fields = ('username', 'email', 'documento', 'telefono')
    list_editable = ('is_active',)

    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Información personal', {'fields': ('first_name', 'last_name', 'email', 'telefono', 'documento')}),
        ('Permisos', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Fechas importantes', {'fields': ('last_login', 'date_joined')}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'password1', 'password2', 'documento', 'telefono', 'is_active', 'is_staff', 'is_superuser')}
        ),
    )

    inlines = [RolUsuarioInline]
    ordering = ('username',)

admin.site.register(Usuario, UsuarioAdmin)
admin.site.register(Rol)
